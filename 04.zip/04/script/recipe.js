var searchElement = document.getElementById('form');
var hasSearched = false;
function search () {
    if (hasSearched) {
        document.getElementById('answere').innerHTML = "";
    } else {
        hasSearched = true;
        var answere = document.createElement('div');
            answere.setAttribute('id', 'answere');
        document.body.appendChild(answere);


        var searchPhrase = document.getElementById('search').value;
        console.log(searchPhrase);
        if (searchPhrase.length > 0) {
            recipes.forEach(function (currentRecipe, index) {
                var database = currentRecipe.name;
                if (database.indexOf(searchPhrase) !== -1) {
                    var result = document.createElement('p');
                        result.textContent = recipes[index].name;
                        result.setAttribute('class', 'result');
                    document.getElementById('answere').appendChild(result);
                }
                else {
                    hasSearched = false;
                }
            })
        }
    }
}


var recipeSection = document.getElementById('recipes');

function detailedRecipe () {
    var currentIndex = event.target.id.substr(3)
    var currentRecipe = recipes[currentIndex]

    var blank = document.createElement('div');
        blank.setAttribute('id', 'blank');
        blank.setAttribute('class', 'blankdiv');
        blank.addEventListener('click', function () {
            document.getElementById('blank').remove();
        })
        document.body.appendChild(blank);
    var detRec = document.createElement('div');
        detRec.setAttribute('id', `${event.target.id}`);
        detRec.setAttribute('class', 'detailedRecipe');
        for (var key in currentRecipe) {

            if (key !== 'ingredients' && key !== 'nutritionInfo') {
                var recipElement = document.createElement('p');
                    recipElement.setAttribute('id', key)
                    recipElement.textContent = `${key} : ${currentRecipe[key]}`;
                detRec.appendChild(recipElement);
            }
            else {
                var recipElement = document.createElement('div');
                if (key === 'ingredients') {
                    recipElement.textContent = `${key}`;
                    currentRecipe.ingredients.forEach(function (currentIngredient, ingredientIndex) {
                        var ingredient = document.createElement('p');
                            ingredient.textContent = `${currentRecipe.ingredients[ingredientIndex].name} : ${currentRecipe.ingredients[ingredientIndex].quantity}${currentRecipe.ingredients[ingredientIndex].quantitySuffix}`;
                        recipElement.appendChild(ingredient);
                    })
                }
                if (key === 'nutritionInfo') {
                    recipElement.textContent = `${key}`;
                    for (var nutriKey in currentRecipe.nutritionInfo) {
                        var nutri = document.createElement('p');
                            nutri.textContent = `${nutriKey} : ${currentRecipe.nutritionInfo[nutriKey]}`
                        recipElement.appendChild(nutri);
                    }
                }
                detRec.appendChild(recipElement);
            }
        }
    blank.appendChild(detRec);
}



recipes.forEach(function (currentRecipe, index) {
    var recipe = document.createElement('div');
        recipe.setAttribute('class', 'simpleRecipe');
        recipe.setAttribute('id', `div${index}`);
        recipe.textContent = `${currentRecipe.name}`;
        recipe.addEventListener('click', detailedRecipe);
        recipeSection.appendChild(recipe);
})

searchElement.addEventListener('input', search);
